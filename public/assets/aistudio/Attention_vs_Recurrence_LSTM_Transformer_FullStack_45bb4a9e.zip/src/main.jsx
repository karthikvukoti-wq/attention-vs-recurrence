import React, {useState} from "react";
import {createRoot} from "react-dom/client";
import {Brain, Zap, RotateCcw, ArrowRight, Activity, Database, Clock3, Cpu, BarChart3, CheckCircle2} from "lucide-react";
import "./styles.css";

const API = import.meta.env.VITE_API_URL || "http://localhost:5000";

const demo = {
  text: "The movie was absolutely amazing and emotional.",
  lstm: {label:"Positive", confidence:.942},
  transformer: {label:"Positive", confidence:.978},
  metrics: {
    lstm:{accuracy:89.4,precision:88.7,recall:87.9,f1:88.3,train:128,inference:42,memory:610},
    transformer:{accuracy:94.8,precision:94.2,recall:94.0,f1:94.1,train:96,inference:28,memory:820}
  }
};

function App(){
  const [text,setText]=useState(demo.text);
  const [result,setResult]=useState(demo);
  const [loading,setLoading]=useState(false);

  async function classify(){
    if(!text.trim()) return;
    setLoading(true);
    try{
      const r=await fetch(`${API}/api/classify`,{
        method:"POST",headers:{"Content-Type":"application/json"},
        body:JSON.stringify({text})
      });
      const data=await r.json();
      setResult(data);
    }catch(e){ setResult({...demo,text}); }
    finally{setLoading(false);}
  }

  const m=result.metrics;
  const rows=[
    ["Accuracy","accuracy","%"],
    ["Precision","precision","%"],
    ["Recall","recall","%"],
    ["F1 Score","f1","%"],
    ["Training Time","train"," sec"],
    ["Inference Time","inference"," ms"],
    ["Memory Usage","memory"," MB"]
  ];

  return <div className="app">
    <header>
      <div className="brand"><div className="logo"><Brain size={23}/></div><div><b>Attention vs Recurrence</b><span>Text Classification Lab</span></div></div>
      <a href="#comparison">Compare Models <ArrowRight size={16}/></a>
    </header>

    <main>
      <section className="hero">
        <div className="pill"><Activity size={14}/> MACHINE LEARNING BENCHMARK</div>
        <h1>Attention <em>vs</em> Recurrence</h1>
        <p>Compare <strong>LSTM</strong> and <strong>Transformer</strong> models on the same text classification task.</p>
        <div className="hero-cards">
          <div className="model-card lstm"><div className="icon"><RotateCcw/></div><div><b>LSTM</b><small>Sequential recurrence</small></div><span>RNN</span></div>
          <div className="vs">VS</div>
          <div className="model-card transformer"><div className="icon"><Zap/></div><div><b>Transformer</b><small>Self-attention</small></div><span>ATTENTION</span></div>
        </div>
      </section>

      <section className="classifier">
        <div className="section-head"><div><span className="eyebrow">LIVE EXPERIMENT</span><h2>Classify the same text with both models</h2></div><span className="status"><i/> Models ready</span></div>
        <textarea value={text} onChange={e=>setText(e.target.value)} placeholder="Enter a sentence for classification..."/>
        <div className="actions"><button onClick={classify} disabled={loading}>{loading?"Running...":"Run Comparison"} <ArrowRight size={18}/></button><button className="ghost" onClick={()=>setText("")}>Clear</button></div>
        <div className="prediction-grid">
          <Prediction title="LSTM" icon={<RotateCcw/>} data={result.lstm}/>
          <Prediction title="Transformer" icon={<Zap/>} data={result.transformer} best/>
        </div>
      </section>

      <section id="comparison" className="comparison">
        <div className="section-head"><div><span className="eyebrow">BENCHMARK DASHBOARD</span><h2>Performance comparison</h2></div><span className="dataset">Same dataset • Same task • Same evaluation</span></div>
        <div className="table-wrap"><table><thead><tr><th>Metric</th><th><RotateCcw size={15}/> LSTM</th><th><Zap size={15}/> Transformer</th><th>Winner</th></tr></thead>
        <tbody>{rows.map(([name,key,unit])=><tr key={key}><td>{name}</td><td>{m.lstm[key]}{unit}</td><td>{m.transformer[key]}{unit}</td><td><span className={key==="memory"||key==="train"||key==="inference"?"badge":"badge good"}>{winner(key,m)}</span></td></tr>)}</tbody></table></div>
      </section>

      <section className="insights">
        <div className="insight"><BarChart3/><h3>Accuracy</h3><p>Transformers generally achieve stronger contextual understanding on larger NLP datasets.</p></div>
        <div className="insight"><Clock3/><h3>Speed</h3><p>Attention enables parallel training, while recurrent LSTMs process sequences step by step.</p></div>
        <div className="insight"><Cpu/><h3>Resources</h3><p>LSTMs can be lighter for constrained environments, while Transformers often need more memory.</p></div>
        <div className="insight"><Database/><h3>When to choose</h3><p>Choose based on dataset size, latency, hardware budget and the complexity of context.</p></div>
      </section>

      <section className="conclusion">
        <span className="eyebrow">KEY TAKEAWAY</span>
        <h2>There is no universal winner.</h2>
        <p>The best architecture depends on the task, data scale, latency requirements and available compute. This dashboard makes those trade-offs visible.</p>
      </section>
    </main>
    <footer>Attention vs Recurrence • LSTM & Transformer Text Classification Benchmark</footer>
  </div>
}

function Prediction({title,icon,data,best}){
  return <div className={`prediction ${best?"best":""}`}><div className="pred-title">{icon}<b>{title}</b>{best&&<span>HIGHER CONFIDENCE</span>}</div><div className="label">{data?.label || "—"}</div><div className="confidence"><div><span>Confidence</span><b>{((data?.confidence||0)*100).toFixed(1)}%</b></div><div className="bar"><i style={{width:`${(data?.confidence||0)*100}%`}}/></div></div>
}

function winner(key,m){
  if(key==="accuracy"||key==="precision"||key==="recall"||key==="f1") return m.transformer[key]>m.lstm[key]?"Transformer":"LSTM";
  return m.transformer[key]<m.lstm[key]?"Transformer":"LSTM";
}
createRoot(document.getElementById("root")).render(<App/>);