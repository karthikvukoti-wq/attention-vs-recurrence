# Attention vs Recurrence — LSTM vs Transformer

A full-stack educational benchmark dashboard for comparing LSTM and Transformer text-classification models.

## Stack
- React + Vite frontend
- Express.js backend
- REST API: `POST /api/classify`
- Responsive dark AI research dashboard

## Run
```bash
npm install
npm run dev
```
Frontend: http://localhost:5173  
Backend: http://localhost:5000

## Important
The included backend uses a lightweight demo scoring function so the project runs without downloading ML weights. For a real ML submission, replace `/api/classify` with your trained LSTM and Transformer inference code or connect it to a Python ML service.

## Suggested real ML architecture
React UI → Express API → Python/FastAPI inference service → trained LSTM + Transformer → metrics/database.
